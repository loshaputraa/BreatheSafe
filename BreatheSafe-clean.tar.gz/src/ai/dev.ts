import { config } from 'dotenv';
config();

import '@/ai/flows/route-health-scoring-fixed';
import '@/ai/flows/pollution-explanation';