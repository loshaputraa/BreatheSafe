"use server";

import { z } from "genkit";
import decode from "google-polyline";
import { GoogleGenerativeAI } from "@google/generative-ai";

const RouteHealthScoreInputSchema = z.object({
  // Prefer encoded polyline when available, but accept legacy callers
  encodedPolyline: z.string().optional(),
  routeMetadata: z.record(z.any()).optional(),
  // Legacy/alternate fields used by callers in `src/lib/actions.ts`
  avgAqi: z.number().optional(),
  routeDistanceKm: z.number().optional(),
  routeDurationMinutes: z.number().optional(),
  trafficLevel: z.string().optional(),
  healthProfile: z.any().optional(),
  travelMode: z.string().optional(),
});

const RouteHealthScoreOutputSchema = z.object({
  healthScore: z.number(),
  explanation: z.string(),
});

function estimateMetersFromPolyline(encoded: string) {
  try {
    const coords = decode.decode(encoded) as Array<[number, number]>;
    let meters = 0;
    for (let i = 1; i < coords.length; i++) {
      const [lon1, lat1] = coords[i - 1];
      const [lon2, lat2] = coords[i];
      const R = 6371000;
      const φ1 = (lat1 * Math.PI) / 180;
      const φ2 = (lat2 * Math.PI) / 180;
      const Δφ = ((lat2 - lat1) * Math.PI) / 180;
      const Δλ = ((lon2 - lon1) * Math.PI) / 180;
      const a = Math.sin(Δφ / 2) * Math.sin(Δφ / 2) + Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
      const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
      meters += R * c;
    }
    return meters;
  } catch (e) {
    return 0;
  }
}

async function callGenerativeAIWithTimeout(apiKey: string, prompt: string, timeoutMs = 4000) {
  const client = new GoogleGenerativeAI({ apiKey });
  const call = client.responses.create({ model: "models/gpt-4o-mini", input: prompt });
  const timeout = new Promise((_, reject) => setTimeout(() => reject(new Error("AI timeout")), timeoutMs));
  return Promise.race([call, timeout]);
}

function safeExtractJson(text: string) {
  const first = text.indexOf("{");
  const last = text.lastIndexOf("}");
  if (first === -1 || last === -1 || last <= first) return null;
  const candidate = text.slice(first, last + 1);
  try { return JSON.parse(candidate); } catch (e) {
    const fixed = candidate.replace(/,\s*}/g, "}").replace(/,\s*]/g, "]");
    try { return JSON.parse(fixed); } catch { return null; }
  }
}

export async function calculateRouteHealthScoreFlow(input: z.infer<typeof RouteHealthScoreInputSchema>) {
  const parsed = RouteHealthScoreInputSchema.parse(input);
  const { encodedPolyline, routeMetadata, routeDistanceKm } = parsed;

  let meters = 0;
  if (encodedPolyline) {
    meters = estimateMetersFromPolyline(encodedPolyline);
  } else if (typeof routeDistanceKm === 'number') {
    meters = Math.round(routeDistanceKm * 1000);
  } else if (routeMetadata && typeof routeMetadata.distanceMeters === 'number') {
    meters = Math.round(routeMetadata.distanceMeters);
  } else {
    meters = 0;
  }

  const fallback = () => {
    const max = 2000;
    const raw = Math.max(0, Math.min(max, meters));
    const score = Math.round((1 - raw / max) * 100);
    return { healthScore: score, explanation: `Approx. ${Math.round(meters)} m; conservative assumptions.` };
  };

  const apiKey = process.env.GOOGLE_API_KEY || process.env.GEMINI_API_KEY;
  if (!apiKey) return RouteHealthScoreOutputSchema.parse(fallback());

  const meta = routeMetadata ? `\nMetadata:\n${JSON.stringify(routeMetadata)}\n` : "";
  const prompt = `RouteLengthMeters:${Math.round(meters)}${meta}`;

  try {
    const resp: any = await callGenerativeAIWithTimeout(apiKey, prompt, 4000);
    let text = "";
    try { text = resp?.output?.[0]?.content ?? resp?.candidates?.[0]?.content ?? (typeof resp === 'string' ? resp : JSON.stringify(resp)); } catch { text = JSON.stringify(resp); }
    const extracted = safeExtractJson(text);
    if (extracted && typeof extracted.healthScore === 'number' && typeof extracted.explanation === 'string') {
      const s = Math.max(0, Math.min(100, Math.round(extracted.healthScore)));
      return RouteHealthScoreOutputSchema.parse({ healthScore: s, explanation: extracted.explanation });
    }
    const match = text.match(/healthScore\D*(\d{1,3})/i);
    if (match) return RouteHealthScoreOutputSchema.parse({ healthScore: Math.max(0, Math.min(100, Number(match[1]))), explanation: text.slice(0, 300) });
    return RouteHealthScoreOutputSchema.parse(fallback());
  } catch (e) {
    return RouteHealthScoreOutputSchema.parse(fallback());
  }
}

export type RouteHealthScoreInput = z.infer<typeof RouteHealthScoreInputSchema>;
export type RouteHealthScoreOutput = z.infer<typeof RouteHealthScoreOutputSchema>;

// Alias the flow to the legacy exported name used across the codebase.
export { calculateRouteHealthScoreFlow as calculateRouteHealthScore };
